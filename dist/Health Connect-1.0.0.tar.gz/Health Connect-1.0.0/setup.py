from setuptools import setup, find_packages

setup(
    name='Health Connect',
    version='1.0.0',
    packages=find_packages(),
)
